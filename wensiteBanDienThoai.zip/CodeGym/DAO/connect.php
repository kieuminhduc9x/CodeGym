<?php
// Biến kết nối toàn cục
global $conn;

// Hàm kết nối database
function connect_db()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Nếu chưa kết nối thì thực hiện kết nối
    if (!$conn){
        $conn = mysqli_connect('localhost', 'root', '', 'bandt') or die ('Can\'t not connect to database');
        // Thiết lập font chữ kết nối
        mysqli_set_charset($conn, 'utf8');
    }
}

// Hàm ngắt kết nối
function disconnect_db()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Nếu đã kêt nối thì thực hiện ngắt kết nối
    if ($conn){
        mysqli_close($conn);
    }
}
// Hàm lấy tất cả sách
function get_all_smartphone()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Hàm kết nối
    connect_db();

    // Câu truy vấn lấy tất cả sinh viên
    $sql = "select * from dienthoai LIMIT 12";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    // Mảng chứa kết quả
    $result = array();

    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($item = mysqli_fetch_assoc($query)){
            $result[] = $item;
        }
    }

    // Trả kết quả về
    return $result;
}



//Hàm tìm kiếm dien thoai
function getUserByID($search){
    global $conn;

    connect_db();

    $sql = "SELECT * FROM bandt.khachhang WHERE MaKH LIKE '%".$search."%' OR TenKH LIKE '%".$search."%'";
    $query = mysqli_query($conn , $sql);
    $result = array();
    if(mysqli_num_rows($query) > 0){
        $item = mysqli_fetch_assoc($query);
        $result = $item;
    }
    return $result;
}
//hàm lấy thông tin khách hàng
function get_all_user()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Hàm kết nối
    connect_db();

    // Câu truy vấn lấy tất cả sinh viên
    $sql = "select * from bandt.khachhang";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    // Mảng chứa kết quả
    $result = array();

    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($item = mysqli_fetch_assoc($query)){
            $result[] = $item;
        }
    }

    // Trả kết quả về
    return $result;
}

//DL đienthoai
function dienthoai()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Hàm kết nối
    connect_db();

    // Câu truy vấn lấy tất cả sinh viên
    $sql = "select * from bandt.dienthoai";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    // Mảng chứa kết quả
    $result = array();

    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($item = mysqli_fetch_assoc($query)){
            $result[] = $item;
        }
    }

    // Trả kết quả về
    return $result;
}
//DL may IPhone
function Iphone()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Hàm kết nối
    connect_db();

    // Câu truy vấn lấy tất cả sinh viên
    $sql = "select * from bandt.dienthoai where Mahang = 1";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    // Mảng chứa kết quả
    $result = array();

    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($item = mysqli_fetch_assoc($query)){
            $result[] = $item;
        }
    }

    // Trả kết quả về
    return $result;
}
//DL may xiaomi
function Xiaomi()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Hàm kết nối
    connect_db();

    // Câu truy vấn lấy tất cả sinh viên
    $sql = "select * from bandt.dienthoai where Mahang = 2";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    // Mảng chứa kết quả
    $result = array();

    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($item = mysqli_fetch_assoc($query)){
            $result[] = $item;
        }
    }

    // Trả kết quả về
    return $result;
}

//DL ddien thoai HOT
function SmartphoneHot()
{
    // Gọi tới biến toàn cục $conn
    global $conn;

    // Hàm kết nối
    connect_db();

    // Câu truy vấn lấy tất cả sinh viên
    $sql = "select * from bandt.dienthoai order by Dongia DESC limit 12 ";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    // Mảng chứa kết quả
    $result = array();

    // Lặp qua từng record và đưa vào biến kết quả
    if ($query){
        while ($item = mysqli_fetch_assoc($query)){
            $result[] = $item;
        }
    }

    // Trả kết quả về
    return $result;
}
//kiem tra dang nhap
function dangnhap($Taikhoan,$Matkhau)
{
    global $conn;
    connect_db();
    $sql = "SELECT * FROM khachhang WHERE TaiKhoan =  '$Taikhoan' AND MatKhau = '$Matkhau'";
    $q = mysqli_query($conn,$sql);
    return $q;
}
// Hàm thêm tai khoan
function dangki($tenkhachhang, $taikhoan, $matkhau, $diachi, $sdt,$level)
{
    // Gọi tới biến toàn cục $conn
    global $conn;
    // Hàm kết nối
    connect_db();
    // Câu truy vấn thêm
    $sql = "
            INSERT INTO bandt.khachhang(TenKH,Taikhoan, Matkhau,Diachi, SDT, Level) VALUES
            ('$tenkhachhang','$taikhoan','$matkhau','$diachi','$sdt','$level')";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    return $query;
}
function addSmartphone($Mamay, $Tenmay, $Mahang, $Hinhanh, $Soluong,$Dongia)
{
    // Gọi tới biến toàn cục $conn
    global $conn;
    // Hàm kết nối
    connect_db();
    // Câu truy vấn thêm
    $sql = "
            INSERT INTO bandt.dienthoai(Mamay,Tenmay,Mahang,Hinhanh,Soluong,Dongia) VALUES
            ('$Mamay','$Tenmay','$Mahang','$Hinhanh','$Soluong','$Dongia')";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    return $query;
}
//sửa thông tin khach hang
function EditUser($MaKH, $Tenkhachhang, $Taikhoan, $Matkhau,$Diachi, $sdt, $Level){
    global  $conn;
    connect_db();
    $sql = "UPDATE bandt.khachhang SET 
            MaKH ='$MaKH',
            TenKH = '$Tenkhachhang',
            Taikhoan = '$Taikhoan',
            Matkhau = '$Matkhau',
            Diachi = '$Diachi',
            SDT = '$sdt',
            Level = '$Level',
            WHERE MaKH = {$MaKH}";
    $query = mysqli_query($conn , $sql);
    return $query;

}
//sua thông tin dienthoai
function EditSmartphone($Mamay, $Tenmay, $Mahang, $Hinhanh,$Soluong, $Dongia){
    global  $conn;
    connect_db();
    $sql = "UPDATE bandt.dienthoai SET 
            Mamay ='$Mamay',
            Tenmay = '$Tenmay',
            Mahang = '$Mahang',
            Hinhanh = '$Hinhanh',
            Soluong = '$Soluong',
            Dongia = '$Dongia',
            WHERE MaKH = {$Mamay}";
    $query = mysqli_query($conn , $sql);
    return $query;

}
//xoa khach hang
function DeleteUser($MaKH){
    global $conn;
    connect_db();

    // Câu truy sửa
    $sql = "
            DELETE FROM bandt.khachhang
            WHERE MaKH = '$MaKH';
    ";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    return $query;

}
//xoa dienthoai
function DeleteSmartphone($Mamay){
    global $conn;
    connect_db();

    // Câu truy sửa
    $sql = "
            DELETE FROM bandt.dienthoai
            WHERE Mamay = '$Mamay';
    ";

    // Thực hiện câu truy vấn
    $query = mysqli_query($conn, $sql);

    return $query;

}