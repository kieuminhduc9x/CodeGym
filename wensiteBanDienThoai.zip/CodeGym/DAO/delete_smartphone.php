<?php

require "connect.php";
$Mamay = $_GET['Mamay'];
DeleteUser($_GET['Mamay']);
header('location: admin.php');
