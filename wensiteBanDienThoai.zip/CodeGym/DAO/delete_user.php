<?php

require "connect.php";
$MaKH = $_GET['MaKH'];
DeleteUser($_GET['MaKH']);
header('location: admin_KH.php');
