<?php
require 'connect.php';
$tenkhachhang = $_POST['tenkhachhang'];
$taikhoan = $_POST['taikhoan'];
$matkhau = $_POST['matkhau'];
$diachi = $_POST['diachi'];
$sdt = $_POST['sdt'];
$level = $_POST['level'];

dangki($tenkhachhang,$taikhoan, $matkhau,$diachi,$sdt,$level);
header('location: ../index.php');
