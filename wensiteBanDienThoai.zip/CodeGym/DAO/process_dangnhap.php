<?php
    require ('connect.php');
$taikhoan = $_POST['taikhoan'];
$matkhau  = $_POST['matkhau'];
dangnhap($taikhoan,$matkhau);
header('location: ../admin.php');
